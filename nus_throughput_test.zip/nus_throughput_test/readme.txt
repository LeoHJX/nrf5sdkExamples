
throughput test with NUS services. throuput results over 1.1Mbps. 

requirements: 
    2 x nRF52840DK
    SDK v16.0
    CI setup to 15ms, through 2M phy. 
    press button 1 on any of the device to start the testing. 

    Please copy the folders: "components_modified" and "modules" to folder "ble_central" and "ble_peripheral" then open the project and compile. 

    run the test. 