/* Copyright (c) 2014 Nordic Semiconductor. All Rights Reserved.
 *
 * The information contained herein is property of Nordic Semiconductor ASA.
 * Terms and conditions of usage are described in detail in NORDIC
 * SEMICONDUCTOR STANDARD SOFTWARE LICENSE AGREEMENT.
 *
 * Licensees are granted free, non-transferable use of the information. NO
 * WARRANTY of ANY KIND is provided. This heading must NOT be removed from
 * the file.
 *
 */

/** @file
 * @defgroup nrf_dev_timer_example_main main.c
 * @{
 * @ingroup nrf_dev_timer_example
 * @brief Timer Example Application main file.
 *
 * This file contains the source code for a sample application using Timer0.
 *
 */

#include <stdbool.h>
#include <stdint.h>
#include "nrf.h"
#include "bsp.h"

#include "nrf_drv_timer.h"
#include "bsp.h"
#include "app_error.h"
#include "nrf_delay.h"
#include "nrf_drv_rtc.h"
#include "nrf_drv_clock.h"

const nrf_drv_timer_t TIMER_LED = NRF_DRV_TIMER_INSTANCE(0);
const nrf_drv_rtc_t rtc = NRF_DRV_RTC_INSTANCE(0); /**< Declaring an instance of nrf_drv_rtc for RTC0. */

const uint8_t leds_list[LEDS_NUMBER] = LEDS_LIST;


void leds_config(void)
{
    //Configure all leds on board.
    LEDS_CONFIGURE(LEDS_MASK);
    LEDS_OFF(LEDS_MASK);	
}

void timer_led_event_handler(nrf_timer_event_t event_type, void* p_context)
{   
    switch(event_type)
    {
        case NRF_TIMER_EVENT_COMPARE0:
            LEDS_ON(BSP_LED_0_MASK);
            break;
				
        case NRF_TIMER_EVENT_COMPARE1:
            LEDS_OFF(BSP_LED_0_MASK);
            break;				
        
        default:
            //Do nothing.
            break;
    }    
}

void timer_config(void)
{
    uint32_t err_code = NRF_SUCCESS;		
	
    //Configure TIMER_LED for generating simple light effect - leds on board will invert his state one after the other.
    err_code = nrf_drv_timer_init(&TIMER_LED, NULL, timer_led_event_handler);
    APP_ERROR_CHECK(err_code);
    
		nrf_drv_timer_compare(&TIMER_LED, NRF_TIMER_CC_CHANNEL0, 3, true);
    nrf_drv_timer_extended_compare(
        &TIMER_LED, NRF_TIMER_CC_CHANNEL1, 10, NRF_TIMER_SHORT_COMPARE1_CLEAR_MASK, true);
    
    nrf_drv_timer_enable(&TIMER_LED);	
}

static void rtc_handler(nrf_drv_rtc_int_type_t int_type)
{
    if (int_type == NRF_DRV_RTC_INT_TICK)
    {
        LEDS_INVERT(BSP_LED_1_MASK);
				NRF_TIMER0->TASKS_COUNT = 1;
    }
}

static void lfclk_config(void)
{
    ret_code_t err_code = nrf_drv_clock_init();
    APP_ERROR_CHECK(err_code);

    nrf_drv_clock_lfclk_request(NULL);
}

static void rtc_config(void)
{
    uint32_t err_code;

    //Initialize RTC instance
    err_code = nrf_drv_rtc_init(&rtc, NULL, rtc_handler);
    APP_ERROR_CHECK(err_code);

    //Enable tick event & interrupt
    nrf_drv_rtc_tick_enable(&rtc,true);

    //Power on RTC instance
    nrf_drv_rtc_enable(&rtc);
}

/**
 * @brief Function for main application entry.
 */
int main(void)
{
		leds_config();
		timer_config();
		lfclk_config();
		rtc_config();

    while(1)
    {
				__WFE();
				__SEV();
				__WFE();
    }
}

/** @} */
